http://people.ee.ethz.ch/~davidsch/vistafm/

Introduction
That's what the World has really been waiting for: 
Since Microsoft changed certain API libraries under 
Windows Vista, it wasn't possible to run the good old 
File Manager (winfile.exe) anymore. With this website, 
the never-ending story's Revival of one of the most clear, 
efficient and fastest file management tools under Windows 
has started! In those rare moments when I was using Windows 
Vista to work with, I was frequently annoyed about the 
slow and lame explorer application which was pumped with 
loads of 32-bit True Color Icons, animated menubars, 
hidden folders, drive-abstracted desktop views and panes 
presenting you all possible operations to perform like 
links on a website. For somebody who never worked with a 
Computer before, explorer might be the best choice to 
start with, but for me and many others it's just a 
nightmare. Now let's stop talking about problems and 
see what kind of solution I can provide for you.



Preparations for basic version with no access control list editing support
You need the file manager executable (winfile.exe) from 
Windows NT 4.0 in the desired language. It's contained 
in Windows NT 4.0 Service Pack 6a (sp6i386.exe, in your 
language), which can be downloaded for free at Microsoft 
without registration procedure. If the link here doesn't 
work just go to www.microsoft.com and search for the 
mentioned Service Pack, it should be easy to find. 
If you already have a 32-bit NT-version of the File Manager 
with long filename support, you can skip this step. 
Once you have downloaded your Service Pack, just execute 
it this way:
sp6i386.exe /X . This will open a Window prompting you to 
enter a directory where to extract all files of the Service 
Pack without installing them. When you are done extracting 
the files, copy winfile.exe to a working directory.

File Manager needs some helper files to start under Vista. 
Download them here and copy them to the working directory 
where you placed winfile.exe.

Finally File Manager (winfile.exe) has to be revived in 
order to make use of the helper files instead of the native 
Windows libraries with those it wouldn't work with. 
Download the wfrevive program to your working directory. 
Run wfrevive.exe in the working directory, where winfile.exe 
is located. 

You're done. just run winfile.exe and enjoy!
 



Additional steps to make ACL editor support work
 
These extra steps are required to follow, if you want the 
access control list (ACL) editor in the File Manager work 
too (menu "Security", entries "Permissions", "Owner", "Audit"). 
You will need some files from an installed Windows XP 
(in the desired language).

Follow the steps 1-4 from the section above. 
Delete the acledwr.dll file in your working directory.

Copy the following files from your Windows XP  
\Windows\System32 directory to your working directory and 
rename them as follows (originalname => newname):

acledit.dll =>   acledwr.dll
mpr.dll     =>   mxp.dll
mprui.dll   =>   mxpui.dll
netui0.dll  =>   netxp0.dll
netui1.dll  =>   netxp1.dll
netui2.dll  =>   netxp2.dll 

Download this additional acl-function-revival program to your 
working directory and run xpaclptc.exe. You're done! To test it, 
run winfile.exe, select a file on a NTFS-drive and select one 
entry of the "Security" menu (or click the key-icon on the toolbar 
once you've selected a filename.

 
Troubleshooting Help 
If you encounter problems with the font display like the ones 
displayed below, you have to go to the "Options"/ "Font" menu 
and choose the font "MS Sans Serif" instead of "Microsoft Sans Serif".

 
If you encounter any problem, don't hesitate to write me:
davidsch@ee.ethz.ch
